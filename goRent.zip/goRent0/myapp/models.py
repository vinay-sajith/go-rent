from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class rental(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone_no=models.CharField(max_length=50)
    license=models.CharField(max_length=400)
    pin=models.CharField(max_length=50)
    post=models.CharField(max_length=50)
    place=models.CharField(max_length=50)
    latitude=models.CharField(max_length=50)
    longitude=models.CharField(max_length=50)
    status=models.CharField(max_length=50)
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)

class user(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=50)
    phone_no=models.CharField(max_length=50)
    pin = models.CharField(max_length=50)
    post = models.CharField(max_length=50)
    place = models.CharField(max_length=50)
    # latitude = models.CharField(max_length=50)
    # longitude = models.CharField(max_length=50)
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)

class category(models.Model):
    category_name=models.CharField(max_length=100)


class vehicle(models.Model):
    vehicle_name=models.CharField(max_length=100)
    vehicle_number=models.CharField(max_length=100)
    image=models.CharField(max_length=100)
    RENTAL=models.ForeignKey(rental,on_delete=models.CASCADE)
    amount=models.CharField(max_length=50)

class rating(models.Model):
    review=models.CharField(max_length=100)
    date=models.CharField(max_length=50)
    rating=models.CharField(max_length=50)
    USER=models.ForeignKey(user,on_delete=models.CASCADE)
    RENTAL=models.ForeignKey(rental,on_delete=models.CASCADE, default=7)


class compliant(models.Model):
    complent=models.CharField(max_length=100)
    reply=models.CharField(max_length=100)
    replydate=models.CharField(max_length=50)
    USER=models.ForeignKey(user,on_delete=models.CASCADE)

class booking(models.Model):
    date=models.CharField(max_length=50)
    status=models.CharField(max_length=100)
    amount=models.CharField(max_length=100)
    USER=models.ForeignKey(user, on_delete=models.CASCADE)
    VEHICLE=models.ForeignKey(vehicle,on_delete=models.CASCADE)
    from_date=models.CharField(max_length=100)
    to_date=models.CharField(max_length=100)
    payment_method=models.CharField(max_length=100)


class payment(models.Model):
    payment_method=models.CharField(max_length=100)
    date=models.CharField(max_length=100)
    amount=models.CharField(max_length=100)
    BOOKING=models.ForeignKey(booking, on_delete=models.CASCADE)







