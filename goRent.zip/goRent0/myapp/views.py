import datetime
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth.models import Group
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from myapp.models import *
import datetime


def login1(request):
    return render(request,'login.html')

def login1_post(request):
    un=request.POST['textfield']
    psw=request.POST['textfield2']
    data=authenticate(request,username=un,password=psw)
    if data is not None:
        login(request,data)
        if data.is_superuser:
            return HttpResponse("<script>alert('success');window.location='/admin_home'</script>")
        if data.groups.filter(name='rental').exists():
            request.session['rid']=rental.objects.get(LOGIN=request.user.id).id
            return HttpResponse("<script>alert('success');window.location='/rental_home'</script>")
        if data.groups.filter(name='user').exists():
            request.session['uid']=user.objects.get(LOGIN=request.user.id).id
            return HttpResponse("<script>alert('success');window.location='/user_homepage'</script>")

    else:
        return HttpResponse("<script>alert('failed');window.location='/'</script>")


def admin_home(request):
    return render(request,"admin/admin_home.html")

@login_required(login_url='/')
def registered_rental(request):
    data=rental.objects.filter(status='pending')
    return render(request,'admin/registered_rental.html',{'data':data})

def approve(request,id):
    rental.objects.filter(id=id).update(status="Approved")
    return HttpResponse("<script>alert('Approved');window.location='/verified_rental';</script>")


def reject(request,id):
    rental.objects.filter(id=id).update(status="rejected")
    return HttpResponse("<script>alert('rejected');window.location='/verified_rental';</script>")


@login_required(login_url='/')
def view_rating(request):
    data=rating.objects.all()
    return render(request,'admin/view_rating.html',{'data':data})

@login_required(login_url='/')
def view_compliant(request):
    data=compliant.objects.all()
    return render(request,'admin/view_compliant.html',{'data':data})

def send_reply(request,id):
    return render(request,'admin/send_reply.html',{'id':id})


def send_reply_post(request,id):
    reply=request.POST['textarea']
    compliant.objects.filter(id=id).update(reply=reply,replydate=datetime.datetime.now().date())
    return HttpResponse("<script>alert('reply send');window.location='/admin_home'</script>")

@login_required(login_url='/')
def verified_rental(request):
    data=rental.objects.filter(status='Approved')
    return render(request,'admin/verified_rental.html',{'data':data})

@login_required(login_url='/')
def admin_change_password(request):
    return render(request,'admin/change password.html')


def admin_change_password_post(request):
    current=request.POST['textfield']
    new=request.POST['textfield2']
    confirm=request.POST['textfield3']
    if new!=confirm:
        return HttpResponse("<script>alert('password not equal');window.location='/admin_home'</script>")
    data=check_password(current,request.user.password)
    if data:
        user=request.user
        user.set_password(new)
        user.save()
        return HttpResponse("<script>alert('password updated successfully');window.location='/admin_home'</script>")


@login_required(login_url='/')
def category_add(request):
    return render(request,'admin/category add.html')

def category_add_post(request):
    category_name=request.POST['textfield']
    obj=category()
    obj.category_name=category_name
    obj.save()
    return HttpResponse("<script>alert('Added successfully');window.location='/admin_home'</script>")

@login_required(login_url='/')
def view_category(request):
    data=category.objects.all()
    return render(request,'admin/view_category.html',{'data':data})

@login_required(login_url='/')
def edit_category(request,id):
    data=category.objects.get(id=id)
    return render(request,'admin/edit_category.html',{'data':data})

def edit_category_post(request,id):
    cat=request.POST['textfield']
    category.objects.filter(id=id).update(category_name=cat)
    return HttpResponse("<script>alert('edited successfully');window.location='/view_category'</script>")

def delete_category(request,id):
    data=category.objects.get(id=id)
    data.delete()
    return HttpResponse("<script>alert('deleted successfully');window.location='/view_category'</script>")


#----------------------------------rental-------------------------------------------------------

def rental_register(request):
    return render(request,'rental/register.html')
def rental_register_post(request):
    na=request.POST['textfield']
    em=request.POST['textfield2']
    ph=request.POST['textfield3']

    lic=request.FILES['fileField']
    fs=FileSystemStorage()
    im=fs.save(lic.name,lic)

    pin=request.POST['textfield4']
    pst=request.POST['textfield5']
    plc=request.POST['textfield6']
    lat=request.POST['textfield7']
    long=request.POST['textfield8']
    pwd=request.POST['textfield9']

    ob=User()
    ob.username=em
    ob.password=make_password(pwd)
    ob.save()

    ob.groups.add(Group.objects.get(name='rental'))

    obj=rental()
    obj.name=na
    obj.email=em
    obj.phone_no=ph
    obj.license=fs.url(im)
    obj.pin=pin
    obj.post=pst
    obj.place=plc
    obj.status='pending'
    obj.latitude=lat
    obj.longitude=long
    obj.LOGIN=ob
    obj.save()

    return HttpResponse("<script>alert('registered successfully');window.location='/'</script>")

# In your myapp/views.py file

def rental_home(request):
    # You can now add any data SPECIFIC to this page, like the recent bookings table
    current_rental = rental.objects.get(id=request.session['rid'])
    recent_bookings = booking.objects.filter(VEHICLE__RENTAL=current_rental).order_by('-date')[:5]

    context = {
        'recent_bookings': recent_bookings
    }
    return render(request, 'rental/rental_home.html', context)

@login_required(login_url='/')
def rental_change_password(request):
    return render(request,'rental/change_password.html')


def rental_change_password_post(request):
    current=request.POST['textfield']
    new=request.POST['textfield2']
    confirm=request.POST['textfield3']
    if new!=confirm:
        return HttpResponse("<script>alert('password not equal');window.location='/rental_change_password'</script>")
    data=check_password(current,request.user.password)
    if data:
        user=request.user
        user.set_password(new)
        user.save()
        return HttpResponse("<script>alert('password updated successfully');window.location='/rental_home'</script>")

@login_required(login_url='/')
def view_profile(request):
    data=rental.objects.filter(id=request.session['rid'])
    return render(request,'rental/view_profile.html',{'data':data})
def edit_profile(request,id):
    data=rental.objects.get(id=id)
    return render(request,'rental/edit_profile.html',{'data':data})

def edit_profile_post(request,id):
    na=request.POST['textfield']
    em=request.POST['textfield2']
    ph=request.POST['textfield3']
    lic=request.FILES['fileField']
    if 'fileField' in request.FILES:
        fs=FileSystemStorage()
        im=fs.save(lic.name,lic)
        rental.objects.filter(id=id).update(license=fs.url(im))
    pin=request.POST['textfield4']
    pst=request.POST['textfield5']
    plc=request.POST['textfield6']
    lat=request.POST['textfield7']
    long=request.POST['textfield8']
    rental.objects.filter(id=id).update(name=na,email=em,phone_no=ph,license=lic,pin=pin,post=pst,place=plc,latitude=lat,longitude=long)

    return HttpResponse("<script>alert('edited successfully');window.location='/view_profile'</script>")

@login_required(login_url='/')
def rental_view_category(request):
    data=category.objects.all()
    return render(request,'rental/view category.html',{'data':data})

@login_required(login_url='/')
def add_vehicle(request):
    return render(request,'rental/add_vehicle.html',)

def add_vehicle_post(request):
    veh=request.POST['textfield']
    vehno=request.POST['textfield2']
    img=request.FILES['fileField']
    fs = FileSystemStorage()
    im = fs.save(img.name,img)
    amt=request.POST['textfield4']

    ob=vehicle()
    ob.vehicle_name=veh
    ob.vehicle_number=vehno
    ob.image=fs.url(im)
    ob.RENTAL_id=request.session['rid']
    ob.amount=amt
    ob.save()
    return HttpResponse("<script>alert('added successfully');window.location='/add_vehicle'</script>")

# AFTER (Corrected code)

@login_required(login_url='/')
def view_vehicle(request):
    # This gets only the vehicles that belong to the logged-in rental partner
    data = vehicle.objects.filter(RENTAL_id=request.session['rid'])
    return render(request, 'rental/view_vehicle.html', {'data': data})

def edit_vehicle(request,id):
    data=vehicle.objects.get(id=id)
    return render(request,'rental/edit_vehicle.html',{'data':data})

def edit_vehicle_post(request,id):
    vehna=request.POST['textfield']
    vehno=request.POST['textfield2']
    amt=request.POST['textfield3']

    if 'photo' in request.FILES:
        img = request.FILES['photo']
        fs = FileSystemStorage()
        im = fs.save(img.name,img)
        vehicle.objects.filter(id=id).update(image=fs.url(im))
    vehicle.objects.filter(id=id).update(vehicle_name=vehna,vehicle_number=vehno,amount=amt)
    return HttpResponse("<script>alert('edited successfully');window.location='/view_vehicle'</script>")

def delete_vehicle(request,id):
    data=vehicle.objects.get(id=id)
    data.delete()
    return HttpResponse("<script>alert('deleted successfully');window.location='/view_vehicle'</script>")

@login_required(login_url='/')
def view_booking(request):
    data=booking.objects.filter(status='pending')
    return render(request,'rental/view_booking.html',{'data':data})

def approve_booking(request,id):
    booking.objects.filter(id=id).update(status="approved")
    return HttpResponse("<script>alert('Approved');window.location='/view_booking'</script>")

def reject_booking(request,id):
    booking.objects.filter(id=id).update(status="rejected")
    return HttpResponse("<script>alert('rejected');window.location='/view_booking'</script>")

@login_required(login_url='/')
def verified_booking(request):
    data=booking.objects.filter(status="approved")
    return render(request,'rental/verified_booking.html',{'data':data})

@login_required(login_url='/')
def view_payment(request):
    data=payment.objects.all()
    return render(request,'rental/view payment.html',{'data':data})


# Add this import at the top of your views.py file
from django.utils import timezone

# Make sure your models are imported
from .models import booking

@login_required(login_url='/')
def view_active_vehicle(request):
    # Get today's date
    today = timezone.now().date()

    # CORRECT: Filter for approved bookings where today's date
    # is between the from_date and to_date for the logged-in rental.
    data = booking.objects.filter(
        VEHICLE__RENTAL_id=request.session['rid'],
        status='approved',
        from_date__lte=today,  # The start date is today or in the past
        to_date__gte=today  # The end date is today or in the future
    ).select_related('VEHICLE', 'USER')

    return render(request, 'rental/view_active_vehicle.html', {'data': data})
@login_required(login_url='/')
def rental_view_rating(request):
    data=rating.objects.all()
    return render(request,'rental/view_rating_.html',{'data':data})



#----------------------------------------------------------------user---------------------------------------------------------------------


def user_homepage(request):
    return render(request,'user/user_homepage_.html')

def user_register(request):
    return render(request,'user/user_register_.html')

def user_register_post(request):
    name=request.POST['textfield']
    email=request.POST['textfield2']
    phone_no=request.POST['textfield3']
    place=request.POST['textfield4']
    post=request.POST['textfield5']
    pin=request.POST['textfield6']
    password=request.POST['textfield7']
    c_password=request.POST['textfield8']

    if  password==c_password:
        obj1 = User()
        obj1.username = email
        obj1.password = make_password(c_password)
        obj1.save()

        obj1.groups.add(Group.objects.get(name='user'))

        obj=user()
        obj.name=name
        obj.email=email
        obj.phone_no=phone_no
        obj.place=place
        obj.post=post
        obj.pin=pin
        obj.LOGIN=obj1
        obj.save()
        return HttpResponse("registerd")

@login_required(login_url='/')
def user_change_password(request):
    return render(request,'user/user_change_password.html')


def user_change_pwd_post(request):
     current = request.POST['textfield']
     new = request.POST['textfield2']
     confirm = request.POST['textfield3']
     if new != confirm:
         return HttpResponse("<script>alert('password not equal');window.location='/user_change_password'</script>")
     data = check_password(current, request.user.password)
     if data:
         user = request.user
         user.set_password(new)
         user.save()
         return HttpResponse("<script>alert('password updated successfully');window.location='/user_homepage'</script>")

@login_required(login_url='/')
def view_user_profile(request):
    data=user.objects.get(id=request.session['uid'])
    return render(request,'user/view_profile_.html',{'data':data})



def edit_user_profile(request,id):
    name=request.POST['textfield']
    email=request.POST['textfield2']
    phone_no=request.POST['textfield3']
    place=request.POST['textfield4']
    post=request.POST['textfield5']
    pin=request.POST['textfield6']
    user.objects.filter(id=id).update(name=name,email=email,phone_no=phone_no,post=post,pin=pin)
    return HttpResponse("<script>alert('edited successfully');window.location='/view_user_profile'</script>")


@login_required(login_url='/')
def view_category_(request):
    data=category.objects.all()
    return render(request,'user/view_category_.html',{'data':data})

@login_required(login_url='/')
def booking_view_vehicle(request, id):
    data=vehicle.objects.filter(RENTAL_id=id)
    return render(request,'user/view_booking.html',{'data':data})


def book_date(request,id):
    amount = vehicle.objects.get(id = id).amount
    return render(request,'user/bookingdate.html',{'id':id,"amount":amount})

def user_booking(request, id):
    fromdate=request.POST['textfield']
    todate=request.POST['textfield2']
    obj=booking()
    obj.date=datetime.datetime.now().date()
    obj.status="pending"
    obj.VEHICLE_id=id
    obj.from_date=fromdate
    obj.to_date=todate
    obj.amount=request.POST['t']
    obj.USER_id=request.session['uid']
    obj.save()
    return HttpResponse("<script>alert('Booked successfully');window.location='/view_booking_status'</script>")

@login_required(login_url='/')
def view_booking_status(request):
    data=booking.objects.filter(USER_id=request.session['uid'])
    for i in data:
        i.amt=int(float(i.amount))
    return render(request,'user/booking_status.html',{'data':data})

def make_payment(request,id,amnt):
    request.session['bid']=id
    request.session['amount']=amnt
    return render(request,'user/make_payment.html')

def make_payment_post(request):
    pay=request.POST['RadioGroup1']
    if pay == 'offline':
        booking.objects.filter(id=request.session['bid']).update(payment_method='offline')
        return HttpResponse("<script>alert('offline booking');window.location='/view_booking_status'</script>")
    else:
        return HttpResponse("<script>alert('online booking');window.location='/default'</script>")


def default(request):
    import razorpay

    razorpay_api_key = "rzp_test_MJOAVy77oMVaYv"
    razorpay_secret_key = "MvUZ03MPzLq3lkvMneYECQsk"

    razorpay_client = razorpay.Client(auth=(razorpay_api_key, razorpay_secret_key))

    amount = int(request.session['amount']) * 100
    # amount = float(amount)

    # Create a Razorpay order (you need to implement this based on your logic)
    order_data = {
        'amount': amount,
        'currency': 'INR',
        'receipt': 'order_rcptid_11',
        'payment_capture': '1',  # Auto-capture payment
    }

    # Create an order
    order = razorpay_client.order.create(data=order_data)

    context = {
        'razorpay_api_key': razorpay_api_key,
        'amount': order_data['amount'],
        'currency': order_data['currency'],
        'order_id': order['id'],
    }

    return render(request, 'user/payment.html',{'razorpay_api_key': razorpay_api_key,
                                            'amount': order_data['amount'],
                                            'currency': order_data['currency'],
                                            'order_id': order['id']})

def payment_online(request):
    booking.objects.filter(id=request.session['bid']).update(payment_method='online')
    return HttpResponse("<script>alert('payment added');window.location='/view_booking_status'</script>")

@login_required(login_url='/')
def send_complient(request):

    return render(request,'user/send_complient.html')


def send_complient_post(request):
    complent=request.POST['textarea']



    obj=compliant()
    obj.complent=complent

    obj.reply='pending'
    obj.replydate=datetime.datetime.now().strftime('%y-%m-%d')
    obj.USER_id=request.session['uid']
    obj.save()
    return HttpResponse("<script>alert('send successfully');window.location='/user_homepage'</script>")

@login_required(login_url='/')
def view_complient_(request):
    data=compliant.objects.all()
    return render(request,'user/view_complient_reply.html',{'data':data})

def send_rating(request, id):
    return render(request,'user/send_reply_.html', {"id":id})


def send_rating_post(request, id):
    # Gets the review from the <textarea>
    revie = request.POST['textarea']

    # CORRECT: Gets the rating number from the star input, which has the name 'textfield'
    ratin = request.POST['textfield']

    obj=rating()
    obj.review = revie
    obj.date = datetime.datetime.now().date()
    obj.rating = ratin # This now saves the number "1", "2", etc.
    obj.RENTAL_id = id
    obj.USER_id = request.session['uid']
    obj.save()

    return HttpResponse("<script>alert('Thank you for your feedback!');window.location='/view_booking_status'</script>")

@login_required(login_url='/')
def view_rating_(request,id):
    data=rating.objects.filter(RENTAL_id=id)
    return render(request,'user/view_rating_.html',{'data':data})


@login_required(login_url='/')
def view_rental(request):
    data=rental.objects.all()
    return render(request,'user/view_rental_.html',{'data':data})

def index(request):
    return render(request,'index.html')

def logouts(request):
    logout(request)
    return HttpResponse("<script>alert('logout successfully');window.location='/'</script>")






