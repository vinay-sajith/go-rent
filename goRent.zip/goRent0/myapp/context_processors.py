# In your new context_processors.py file

from .models import rental, vehicle, booking, rating
from django.db.models import Avg


def rental_dashboard_data(request):
    # Check if a rental user is logged in and has a session 'rid'
    if request.user.is_authenticated and 'rid' in request.session:
        try:
            current_rental = rental.objects.get(id=request.session['rid'])

            # Perform all the same calculations as before
            total_vehicles = vehicle.objects.filter(RENTAL=current_rental).count()
            new_bookings = booking.objects.filter(VEHICLE__RENTAL=current_rental, status='pending').count()
            total_bookings = booking.objects.filter(VEHICLE__RENTAL=current_rental).count()
            avg_rating_data = rating.objects.filter(RENTAL=current_rental).aggregate(avg=Avg('rating'))
            avg_rating = round(avg_rating_data['avg'], 1) if avg_rating_data['avg'] else 'N/A'

            # Return a dictionary with all the data
            return {
                'rental_name': current_rental.name,
                'total_vehicles': total_vehicles,
                'new_bookings': new_bookings,
                'total_bookings': total_bookings,
                'avg_rating': avg_rating,
            }
        except rental.DoesNotExist:
            pass  # If rental profile is not found, do nothing

    # Return an empty dictionary if no user is logged in or no 'rid'
    return {}